﻿using StripsBL.Model;
using StripsREST.Model.Output;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StripsClientWPFStripView.Model {
    public class StripsWpfOutput {
        public StripsWpfOutput(StripsRESToutputDto strip, int id) {
            Titel = strip.Titel;
            Nr = strip.Nr;
            Reeks = strip.ReeksNaam;
            Uitgeverij = strip.Uitgeverij;
            Auteurs = strip.Auteurs.Select(x =>x.Naam).ToList();
            stripId = id;
        }



        private int stripId;
        private string titel;
        private int? nr;
        private string reeks;
        private string uitgeverij;
        private List<string> auteurs = new List<string>();


        public int StripId {
            get { return stripId; }
            set {
                stripId = value;
                OnPropertyChanged("StripId");
            }
        }

        public string Titel {
            get { return titel; }
            set {
                titel = value;
                OnPropertyChanged("Titel");
            }
        }

        public int? Nr {
            get { return nr; }
            set {
                nr = value;
                OnPropertyChanged("Nr");
            }
        }

        public string Reeks {
            get { return reeks; }
            set {
                reeks = value;
                OnPropertyChanged("Reeks");
            }
        }

        public string Uitgeverij {
            get { return uitgeverij; }
            set {
                uitgeverij = value;
                OnPropertyChanged("Uitgeverij");
            }
        }

        public List<string> Auteurs {
            get { return auteurs; }
            set {
                auteurs = value;
                OnPropertyChanged("Auteurs");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName) {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
