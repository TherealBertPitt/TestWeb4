﻿using StripsClientWPFStripView.Exceptions;
using System;
using System.DirectoryServices.ActiveDirectory;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using StripsBL.Model;
using StripsREST.Model.Output;

namespace StripsClientWPFStripView.Services
{
    public class StripServiceClient
    {
        private HttpClient client = new HttpClient();

        public StripServiceClient()
        {
            client.BaseAddress = new Uri("http://localhost:5044/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task<StripsRESToutputDto> GetStripAsync(string path) {
            try {
                StripsRESToutputDto strip = null;
                HttpResponseMessage response = await client.GetAsync(path);
                if(response.IsSuccessStatusCode) {
                    strip = await response.Content.ReadAsAsync<StripsRESToutputDto>();
                }
                return strip;
            } catch (Exception ex) {

                Console.WriteLine(ex); 
                return null;
            }
        }
    }
}
