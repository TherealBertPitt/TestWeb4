﻿using StripsBL.Model;
using StripsClientWPFStripView.Model;
using StripsClientWPFStripView.Services;
using StripsREST.Model.Output;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StripsClientWPFStripView
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private StripServiceClient stripService;
        private StripsWpfOutput wpfOutput;
        private string path;
        public MainWindow()
        {
            InitializeComponent();
            stripService = new StripServiceClient();
            DataContext = wpfOutput;
        }

        private async void GetStripButton_Click(object sender, RoutedEventArgs e)
        {
            try {
                if (int.TryParse(StripIdTextBox.Text, out int stripId) && stripId > 0) {
                    // Call your GeefStrip function to retrieve the Strip object by its ID
                    StripsRESToutputDto strip = await stripService.GetStripAsync($"http://localhost:5044/api/strips/beheer/{stripId}");

                    if (strip != null) {
                        StripsWpfOutput stripOutput = new(strip, stripId);
                        StripIdTextBox.Text = stripOutput.StripId.ToString();
                        TitelTextBox.Text = stripOutput.Titel;
                        NrTextBox.Text = stripOutput.Nr.ToString();
                        ReeksTextBox.Text = stripOutput.Reeks;
                        UitgeverijTextBox.Text = stripOutput.Uitgeverij;
                        AuteurListBox.ItemsSource = stripOutput.Auteurs;
                    } else {
                        MessageBox.Show("Strip not found in the database.");
                    }
                } else {
                    MessageBox.Show("Please enter a valid positive ID.");
                }
            } catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
