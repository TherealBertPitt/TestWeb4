﻿using StripsBL.Interfaces;
using StripsBL.Model;
using StripsDL.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace StripsDL.Repositories {
    public class StripsRepository : IStripsRepository {
        private string connectionString;

        public StripsRepository(string connectionString) {
            this.connectionString = connectionString;
        }

        public Strip GeefStrip(int id) {
            string auteursSql = "Select Auteur.Id, Auteur.Naam FROM Strip " +
                                "JOIN StripAuteur on Strip.Id = StripAuteur.StripId " +
                                "JOIN Auteur on StripAuteur.AuteurId = Auteur.Id " +
                                "WHERE Strip.Id = @StripId;";

            using (SqlConnection connection = new SqlConnection(connectionString)) {
                using (SqlCommand command = connection.CreateCommand()) {
                    List<Auteur> auteurs = new List<Auteur>();
                    try {
                        // Eerste command om auteurs van de strip op te vragen en in een lijst te zetten
                        connection.Open();
                        command.CommandText = auteursSql;
                        command.Parameters.AddWithValue("@StripId", id);
                        IDataReader dr = command.ExecuteReader();
                        while (dr.Read()) {
                            auteurs.Add(new(
                                (int)dr["Id"],
                                (string)dr["Naam"]));
                        }
                        dr.Close();

                        // TWeede command om het strip-object te kunnen aanmaken
                        string restSql = "SELECT Strip.Id as StripId, strip.Titel, Strip.Nr, Reeks.Naam as ReeksNaam, Reeks.Id as ReeksId, Uitgeverij.Naam as UitgeverijNaam, Uitgeverij.Id as UitgeverijId " +
                                         "FROM Strip " +
                                         "JOIN Reeks on Strip.Reeks = Reeks.Id " +
                                         "JOIN Uitgeverij ON Strip.Uitgeverij = Uitgeverij.Id " +
                                         "WHERE Strip.Id=@StripId;";


                        command.CommandText = restSql;
                        dr = command.ExecuteReader();
                        dr.Read();
                        Strip strip = new Strip(
                                      (int)dr["StripId"],
                                      (string)dr["Titel"],
                                      (int)dr["Nr"],
                                      new Reeks(
                                          (int)dr["ReeksId"],
                                          (string)dr["ReeksNaam"]),
                                      new Uitgeverij(
                                          (int)dr["UitgeverijId"],
                                          (string)dr["UitgeverijNaam"]),
                                      auteurs
                                      );
                        dr.Close();
                        return strip;
                    } catch (Exception ex) {
                        throw new StripsRepositoryException("GeefStrip", ex);
                    } 
                }
            }
        }
    }
}
          