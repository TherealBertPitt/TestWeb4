﻿using StripsBL.Model;

namespace StripsREST.Model.Output {
    public class StripsRESToutputDto {
        public StripsRESToutputDto(string url, string titel, int? nr, string reeksNaam, string reeksUrl, string uitgeverijNaam, string uitgeverijUrl, List<AuteurRESToutputDto> auteurs) {
            Url = url;
            Titel = titel;
            Nr = nr;
            ReeksNaam = reeksNaam;
            ReeksUrl = reeksUrl;
            Uitgeverij = uitgeverijNaam;
            UitgeverijUrl = uitgeverijUrl;
            Auteurs = auteurs;
        }

        public string Url { get; set; }
        public string Titel { get; set; }
        public int? Nr { get; set; }
        public string ReeksNaam { get; set; }
        public string ReeksUrl { get; set; }
        public string Uitgeverij { get; set; }
        public string UitgeverijUrl {  get; set; }
        public List<AuteurRESToutputDto> Auteurs { get; set; }
    }
}
