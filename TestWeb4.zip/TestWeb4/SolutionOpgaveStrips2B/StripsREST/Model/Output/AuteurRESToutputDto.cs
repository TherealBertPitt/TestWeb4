﻿namespace StripsREST.Model.Output {
    public class AuteurRESToutputDto {
        public AuteurRESToutputDto(string naam, string auteurUrl) {
            Naam = naam;
            AuteurUrl = auteurUrl;
        }

        public string Naam {  get; set; }
        public string AuteurUrl { get; set; }
    }
}
