﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StripsBL.Exceptions;
using StripsBL.Managers;
using StripsBL.Model;
using StripsREST.Mappers;

namespace StripsREST.Controllers
{
    [Route("api/[controller]/beheer")]
    [ApiController]
    public class StripsController : ControllerBase
    {
        private StripsManager stripsManager;
        private string url = "http://localhost:5044/api/strips";

        public StripsController(StripsManager stripsManager)
        {
            this.stripsManager = stripsManager;
        }

        [HttpGet("{id}")]
        public ActionResult GetStrip(int id) {
            try {
                Strip strip = stripsManager.GeefStrip(id);
                return Ok(MapFromDomain.MapFromStripDomain(url, strip, stripsManager));
            } catch (Exception ex) {
                return NotFound(ex.Message);
            }
        }
    }
}
