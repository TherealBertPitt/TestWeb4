﻿using StripsBL.Managers;
using StripsBL.Model;
using StripsREST.Model.Output;

namespace StripsREST.Mappers {
    public class MapFromDomain {
        public static StripsRESToutputDto MapFromStripDomain(string url, Strip strip, StripsManager manager) {
			try {
                string stripUrl = $"{url}/beheer/strip/{strip.ID}";
                List<AuteurRESToutputDto> auteursDto = new List<AuteurRESToutputDto>();

                foreach(Auteur auteur in strip.Auteurs ) {
                    auteursDto.Add(new(auteur.Naam, $"{url}/beheer/auteur/{auteur.ID}"));
                }

                List<AuteurRESToutputDto> auteursSorted = new(auteursDto.OrderBy(x => x.Naam));

                string reeksUrl = $"{url}/beheer/reeks/{strip.Reeks.ID}";
                string uitgeverijUrl = $"{url}/beheer/uitgeverij/{strip.Uitgeverij.ID}";

                StripsRESToutputDto dto = new(url, strip.Titel, strip.Nr, strip.Reeks.Naam,reeksUrl, strip.Uitgeverij.Naam, uitgeverijUrl, auteursSorted);
                return dto;
			} catch (Exception) {

				throw;
			}
        }
    }
}
